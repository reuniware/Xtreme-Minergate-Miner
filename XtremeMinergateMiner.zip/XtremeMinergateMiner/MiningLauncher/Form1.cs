﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XtremeMinergateMiner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Application.ApplicationExit += new EventHandler(this.OnApplicationExit);

            txtEmail.Text = @"investdatasystems@yahoo.com";

            if (MinersAreRunning() == true)
            {
                stopXmrig();
                stopXmrminer();
            }
        }

        ProcessStartInfo processInfo;
        Process process;
        String command = "";

        private void stopXmrig()
        {
            command = @"taskkill /F /IM xmrig.exe";
            processInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
            processInfo.CreateNoWindow = true;
            processInfo.UseShellExecute = false;
            processInfo.RedirectStandardError = false;
            processInfo.RedirectStandardOutput = false;
            process = Process.Start(processInfo);
            process.WaitForExit();
        }

        private void startXmrig()
        {
            String strSafe = "";
            if (checkboxSafe.Checked) strSafe = "--safe"; else strSafe = "";
            String strCpuPriority = "";
            strCpuPriority = numericCpuPriority.Value.ToString();
            //String strMaxCpuUsage = "";
            //strMaxCpuUsage = numericMaxCpuUsage.Value.ToString();
            String strNumberOfThreads = "";
            strNumberOfThreads = numericNumberOfThreads.Value.ToString();

            //command = @"C:\tmp\githubprojects\xmrig\build\Release\xmrig.exe -o stratum+tcp://bcn.pool.minergate.com:45550 -u investdatasystems@yahoo.com -p x --safe --cpu-priority 5 --donate-level=1 --av=0 --threads=4";
            command = Directory.GetCurrentDirectory() + @"\extapps\xmrig.exe -o stratum+tcp://bcn.pool.minergate.com:45550 -u " + email + " -p x " + strSafe + " --cpu-priority " + strCpuPriority + " --donate-level=1 --av=0 --threads=" + strNumberOfThreads;// + " --max-cpu-usage=" + strMaxCpuUsage;
            //MessageBox.Show(command);
            processInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
            processInfo.CreateNoWindow = true;
            processInfo.UseShellExecute = false;
            processInfo.RedirectStandardError = true;
            processInfo.RedirectStandardOutput = true;
            process = Process.Start(processInfo);
            process.OutputDataReceived += new DataReceivedEventHandler(XmrigProcess_OutputDataReceived);
            process.BeginOutputReadLine();
            process.ErrorDataReceived += new DataReceivedEventHandler(XmrigProcess_ErrorDataReceived);
            process.BeginErrorReadLine();
        }

        private void XmrigProcess_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            String str = e.Data;
            if (str is null) return;
            try
            {
                this.Invoke((MethodInvoker)delegate () {
                    if (txtXmrigLog.TextLength >= txtXmrigLog.MaxLength) txtXmrigLog.Clear();
                    txtXmrigLog.AppendText(str + "\r\n");
                });
            }
            catch (Exception)
            {
            }
        }

        private void XmrigProcess_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            String str = e.Data;
            if (str is null) return;
            try
            {
                this.Invoke((MethodInvoker)delegate () {
                    if (txtXmrigLog.TextLength >= txtXmrigLog.MaxLength) txtXmrigLog.Clear();
                    txtXmrigLog.AppendText("ERROR : " + str + "\r\n");
                });
            }
            catch (Exception)
            {
            }
        }

        private void stopXmrminer()
        {
            command = @"taskkill /F /IM xmrMiner_0.2.1.exe";
            processInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
            processInfo.CreateNoWindow = true;
            processInfo.UseShellExecute = false;
            processInfo.RedirectStandardError = false;
            processInfo.RedirectStandardOutput = false;
            process = Process.Start(processInfo);
            process.WaitForExit();
        }

        private void startXmrminer()
        {
            command = Directory.GetCurrentDirectory() + @"\extapps\xmrMiner_0.2.1.exe -o stratum+tcp://bcn.pool.minergate.com:45550 -u " + email + " -p x";
            processInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
            processInfo.CreateNoWindow = true;
            processInfo.UseShellExecute = false;
            processInfo.RedirectStandardError = true;
            processInfo.RedirectStandardOutput = true;
            process = Process.Start(processInfo);
            process.OutputDataReceived += new DataReceivedEventHandler(XmrminerProcess_OutputDataReceived);
            process.BeginOutputReadLine();
            process.ErrorDataReceived += new DataReceivedEventHandler(XmrminerProcess_ErrorDataReceived);
            process.BeginErrorReadLine();
        }

        private void XmrminerProcess_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            String str = e.Data;
            if (str is null) return;
            try
            {
                this.Invoke((MethodInvoker)delegate () {
                    if (txtXmrminerLog.TextLength >= txtXmrminerLog.MaxLength) txtXmrminerLog.Clear();
                    txtXmrminerLog.AppendText(str + "\r\n");
                });
            }
            catch (Exception)
            {
            }
        }

        private void XmrminerProcess_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            String str = e.Data;
            if (str is null) return;
            try
            {
                this.Invoke((MethodInvoker)delegate () {
                    if (txtXmrminerLog.TextLength >= txtXmrminerLog.MaxLength) txtXmrminerLog.Clear();
                    txtXmrminerLog.AppendText("ERROR : " + str + "\r\n");
                });
            }
            catch (Exception)
            {
            }
        }


        private Boolean MinersAreRunning()
        {
            Process[] allProcs = Process.GetProcesses();
            foreach (Process proc in allProcs)
            {
                ProcessThreadCollection myThreads = proc.Threads;
                if (proc.ProcessName.ToLower().Contains("xmrig") || proc.ProcessName.ToLower().Contains("xmrminer"))
                {
                    return true;
                }
            }
            return false;
        }

        Thread thread = null;
        Thread threadWatchdog = null;
        String email = "";
        private void button1_Click(object sender, EventArgs e)
        {
            if (MinersAreRunning())
            {
                return;
            }

            email = txtEmail.Text.Trim();
            if (email == "")
            {
                MessageBox.Show("Please enter an email address");
                return;
            }

            txtXmrigLog.Clear();

            threadWatchdog = new Thread(this.watchdog);
            threadWatchdog.Start();

            stopXmrig();
            startXmrig();
            stopXmrminer();
            startXmrminer();

            thread = new Thread(this.DoWork);
            thread.Start();

            if (cbHide.Checked)
            {
                this.Visible = false;
            }
        }

        DateTime dt;
        DayOfWeek dow;
        public void DoWork(object data)
        {
            while (true)
            {
                dt = DateTime.Now;
                dow = dt.DayOfWeek;

                if (MinersAreRunning() == false)
                {
                    stopXmrig();
                    startXmrig();
                    stopXmrminer();
                    startXmrminer();
                }

                Thread.Sleep(2500);
            } // fin while true thread
        
        }

        public void watchdog(object data)
        {
            while (true)
            {
                try
                {
                    if (MinersAreRunning()) { this.Invoke((MethodInvoker)delegate () { txtStatus.Text = "Started"; panelXmrigSettings.Enabled = false; cbHide.Enabled = false;  }); }
                    else { this.Invoke((MethodInvoker)delegate () { txtStatus.Text = "Stopped"; panelXmrigSettings.Enabled = true; cbHide.Enabled = true; }); }
                }
                catch (Exception)
                {
                }
            }
        }

        private void btnStopMiners_Click(object sender, EventArgs e)
        {
            if (thread != null)
            {
                thread.Abort();
            }

            if (MinersAreRunning() == true)
            {
                stopXmrig();
                stopXmrminer();
            }
        }

        private void OnApplicationExit(object sender, EventArgs e)
        {
            if (thread != null)
            {
                thread.Abort();
            }

            if (MinersAreRunning() == true)
            {
                stopXmrig();
                stopXmrminer();
            }

            if (threadWatchdog != null)
            {
                threadWatchdog.Abort();
            }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://ichimoku-expert.blogspot.com");
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("mailto://investdatasystems@yahoo.com");
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://etherscan.io/address/0x4ED81C78757fdC5D51529F843Dc6ad96F8B45F16");
        }
    }
}
